using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using WordCount;
using WordCount.Models;

namespace WordCountTests
{
    [TestClass]
    public class Tests
    {

        Text testText = new Text();


        [TestMethod]
        public void removePunctuationTest()
        {
            string testString = "If there isn't any punctuation, this might be un-read-able (right??).";
            string expected = "If there isnt any punctuation this might be unreadable right";

            StringAssert.Equals(expected, testText.removePunctuation(testString));
            StringAssert.Equals("pop pop pop", testText.removePunctuation("pop-pop-pop"));
            StringAssert.Equals("letter upon letter", testText.removePunctuation("letter - upon - letter"));
            StringAssert.Equals("under the breath", testText.removePunctuation("under-the-breath"));
        }

        [TestMethod]
        public void toTextDictTest()
        {
            string testString = "ab bc bc cde cde cde efg efg efg efg efg";
            Dictionary<string, int> expected = new Dictionary<string, int>
                {
                {"ab", 1 },
                {"bc", 2 },
                {"cde", 3 },
                {"efg", 5 }
                };

            CollectionAssert.Equals(expected, testText.toTextDict(testString));
        }

    }
}
