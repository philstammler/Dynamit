﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WordCount.Models;

namespace WordCount.Controllers
{
    public class HomeController : Controller
    {
        private string filePath = "wwwroot/Paragraph.txt";

        public IActionResult Index()
        {
            Text textObj = new Text();

            string fullText = textObj.getFullText(filePath);

            Dictionary<string, int> text = textObj.toTextDict(fullText);

            return View(text);
        }
        
    }
}
