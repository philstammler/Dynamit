﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WordCount.Models
{
    public class Text
    {

        public string getFullText(string filePath)
        {
            string text = "";

            using (StreamReader sr = new StreamReader(filePath))
            {
                while (!sr.EndOfStream)
                {
                    text = sr.ReadToEnd();
                }
            }
            return text;
        }

        public Dictionary<string, int> toTextDict(string text) 
        {

            text = removePunctuation(text);
            string[] fullTextArray = text.Split(" ");

            Dictionary<string, int> numberedWords = new Dictionary<string, int>();
            for (int i = 0; i < fullTextArray.Length; i++)
            {
                if (!numberedWords.ContainsKey(fullTextArray[i]))
                {
                    numberedWords.Add(fullTextArray[i], 1);
                }
                else
                {
                    numberedWords[fullTextArray[i]]++;
                }
            }
            return numberedWords;
        }

        public string removePunctuation(string textString) 
        {
            string noNewLine = Regex.Replace(textString, @"[-]", " "); 
            string result = Regex.Replace(textString, @"[^\w\s]", "");
            return result;
        }


    }
}
