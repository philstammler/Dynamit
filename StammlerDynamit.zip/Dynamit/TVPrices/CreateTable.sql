
DROP TABLE TVPrices;
GO

CREATE TABLE TVPrices
(
	TVModel		varchar(50)	not null,
	DateUpdated	varchar(50)	not null,
	Price		money	not null,

);

